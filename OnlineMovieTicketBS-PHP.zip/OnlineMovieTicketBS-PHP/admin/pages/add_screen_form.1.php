<div class="form-group">
    <input type="text" name="name" id="sname" placeholder="Screen Name" class="form-control"/>
</div>
<div class="form-group">
    <input type="number" name="seats" id="sseats" placeholder="Seats" class="form-control"/>
</div>
<div class="form-group">
    <input type="number" name="charge" id="scharge" placeholder="Ticket Charge" class="form-control"/>
</div>
<div class="form-group">
    <button type="button" class="btn btn-success" id="savescreen">Save</button>
</div>